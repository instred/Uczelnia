﻿namespace z1
{
    public interface ICommand
    {
        void Execute();
    }
}