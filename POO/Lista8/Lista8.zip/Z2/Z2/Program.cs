﻿
namespace Z2 {
    
    public static class Example {
        
        public static void Main() {
            var xml = new XmlHandler("example.xml");
            xml.Execute();
        }
    }
}