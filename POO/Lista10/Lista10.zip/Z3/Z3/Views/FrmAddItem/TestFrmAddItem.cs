﻿namespace Z3.Views.FrmAddItem
{
    public class TestFrmAddItem : IFrmAddItem
    {
        public FrmAddItemPresenter Presenter { get; set; }

        public void ShowModal()
        {
        }
    }
}
