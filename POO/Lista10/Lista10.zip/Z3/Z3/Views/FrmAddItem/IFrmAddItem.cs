﻿namespace Z3.Views.FrmAddItem
{
    public interface IFrmAddItem
    {
        FrmAddItemPresenter Presenter { set; }
        void ShowModal();
    }
}
